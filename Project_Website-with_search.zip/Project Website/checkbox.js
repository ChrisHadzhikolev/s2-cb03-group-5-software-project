function myFunction() {
  var checkBox = document.getElementById("myCheck");
  var text = document.getElementById("text");
  if (checkBox.checked == true) {
    text.style.display = "block";
  } else {
    text.style.display = "none";
  }
}
function myFunction1() {
  var checkBox = document.getElementById("myCheck_absent");
  var text = document.getElementById("text_a");
  if (checkBox.checked == true) {
    text.style.display = "block";
  } else {
    text.style.display = "none";
  }
}
function myFunction1() {
  var checkBox = document.getElementById("myCheck_sick");
  var text = document.getElementById("text_s");
  if (checkBox.checked == true) {
    text.style.display = "block";
  } else {
    text.style.display = "none";
  }
}
