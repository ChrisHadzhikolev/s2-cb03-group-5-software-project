<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link rel="stylesheet" href="navBar.css">
<link rel="stylesheet" href="profilePage.css">
    <title>Profile</title>
</head>
<body>
<?php
require_once "navBar.php";
?>
 <div class="container">    
                  <div class="row">
                      <div class="panel panel-default">
                      <div class="panel-heading">  <h4 >Edit personal info</h4></div>
                       <div class="panel-body">
                      <div class="col-md-4 col-xs-12 col-sm-6 col-lg-4">
                       <img src="<?php 
          $name = $_SESSION['uname'];
          if(file_exists("pics/$name.png"))
          {
            echo "pics/$name.png"."?". rand(99,9999) .'/>';
          }
          else{
            echo "pics/default.png"."?". rand(99,9999) .'/>';
          }
          
          ?>"class="img-circle img-responsive"> 
                       <input style="margin-top: 1cm;" type="file" class="form-control" name="image" >
          <button class="btn btn-primary" name ="postpic" type="submit"  style="background-color:black;border-color: black;color:#a5b3fe">
          Update picture
          </button>
                      
                      </div>
                      <div class="col-md-8 col-xs-12 col-sm-6 col-lg-8" >
                          <div class="container" >
                            <h2>John Doe</h2>
                            <p>an   <b> Employee</b></p>
                          
                           
                          </div>
                           <hr>
                          <ul class="container details" >
                          <div class="form-group">
            <label class="col-lg-3 control-label">Email:</label>
            <div class="col-lg-8">
              <input class="form-control" type="text" value="<?php echo  $result['email']?>" name ="email">
            </div>
          </div>
          <div class="form-group">
            <label class="col-lg-3 control-label">Number:</label>
            <div class="col-lg-8">
              <input class="form-control" type="text" value="<?php echo  $result['phone_number']?>" name="nr">
            </div>
          </div>
          <div class="form-group">
            <label class="col-md-3 control-label">Password:</label>
            <div class="col-md-8">
              <input class="form-control" type="password" value="" name="psw">
            </div>
          </div>
          <div class="form-group">
            <label class="col-md-3 control-label">Confirm password:</label>
            <div class="col-md-8">
              <input class="form-control" type="password" value="" name="psw2">
            </div>
          </div>
                          <div style="margin-left:6cm"class="col-md-8">
              <a href="EditInfo.php"><input type="button" class="btn btn-primary" value="Save changes" style="margin-top: 1cm;background-color:black;border-color: black;color:#a5b3fe"></a>
              <a href="changePassword.php"><input type="button" class="btn btn-primary" value="Change password" style="margin-top: 1cm;background-color:black;border-color: black;color:#a5b3fe"></a>
              <input type="reset" class="btn btn-default" value="Cancel" style="margin-top: 1cm;background-color:#a5b3fe;border-color: black;color:black">
            </div>
                      </div>
                      
                </div>
                
            </div>
            </div>
</body>
</html>