
<nav class="navbar navbar-expand-lg " style="background-color: black">

  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul  class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="index.php">Dashboard</a>
      </li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Employee
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="profile.php">Profile</a>
          <a class="dropdown-item" href="mailto:name@email.com">Contact manager</a>
          <a class="dropdown-item" href="editInfo.php">Edit information</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="schedule.php">Schedule</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Messages</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Logout</a>
      </li>
    </ul>
  </div>
</nav>  
