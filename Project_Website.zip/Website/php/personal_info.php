<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Volkhov&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Merriweather:400,900,900i" rel="stylesheet">


<link ref="stylesheet" href="../css/header.css">
<link ref="stylesheet" href="../css/personal_info.css">
<div class="navigation">
    <nav>
        <ul>
            <li ><a><span>MediaBazaar</span></a></li>
            <li class="home"><a href="php/NewsPage.php">News</a></li>
            <li class="home"><a href="php/personal_info.php">Information</a></li>
            <li class="home"><a href="php/schedule.php">Schedule</a></li>
            <li class="home"><a href="php/ContactUsPage.php">Contact manager</a></li>
            <li class="login_reg" ><a href="php/LoginPage.php">Sign out</a></li>
        
        </ul>
    </nav>
</div>
<div class="main">

<h2 style="text-align:center">User Profile Card</h2>

<div class="card">
  <img src="../img_avatar2.png" alt="John" style="width:10%">
  <h1>John Doe</h1>
  <p class="title">CEO & Founder, Example</p>
  <p>Harvard University</p>
</div>
</div>
</body>
</html>