<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="keywords" content="footer, address, phone, icons"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">


    <link rel="stylesheet" href="css/index_style.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/header.css">
    

    <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Volkhov&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Merriweather:400,900,900i" rel="stylesheet">

    <title>Media Bazaar</title>
</head>
<body>
<div class="navigation">
    <nav>
        <ul>
            <li ><a><span>MediaBazaar</span></a></li>
            <li class="home"><a href="php/NewsPage.php">News</a></li>
            <li class="home"><a href="php/personal_info.php">Information</a></li>
            <li class="home"><a href="php/schedule.php">Schedule</a></li>
            <li class="home"><a href="php/ContactUsPage.php">Contact manager</a></li>
            <li class="login_reg" ><a href="php/LoginPage.php">Sign out</a></li>
        
        </ul>
    </nav>
</div>
<div class="main">
<div class="bg-text">
  <h1 style="font-size:60px">Personal information</h1>
  <h1 style="font-size:60px">Schedule</h1>
  <h1 style="font-size:60px">Messages</h1>
  <!--<a class="button" href="php/login.php">Log in</a>-->
</div>
  
</div>

   <!-- <a class="button" href="php/AboutUsPage.php">Click Me</a>
</div>-->
<a id="back_to_top"></a>
<script type="text/javascript" src="js/backToTop.js"></script>
<!-- <?php
/*include("php/config.php");

if (isset($_POST['but_upload'])) {

    $name = $_FILES['file']['name'];
    $target_dir = "upload/";
    $target_file = $target_dir . basename($_FILES["file"]["name"]);

    // Select file type
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Valid file extensions
    $extensions_arr = array("jpg", "jpeg", "png", "gif");

    // Check extension
    if (in_array($imageFileType, $extensions_arr)) {

        // Insert record

        $query = "insert into images(Id, Name, Image) values(null, '" . $name . "', 'Hmm')";
        mysqli_query($con, $query);

        // Upload file
        move_uploaded_file($_FILES['file']['tmp_name'], $target_dir . $name);
    }
}*/
?>

        <!--<form method="post" action="" enctype='multipart/form-data'>
            <input type='file' name='file' />
            <input type='submit' value='Save name' name='but_upload'>
        </form>-->
<footer class="footer">
    <div class="footer-left">
        <!-- <img src="drawable/logo.png">-->
        <h3>-> <span>Media Bazaar</span></h3>

        <p class="footer-links">
            <a href="#">Home</a>
            |
            <a href="#">News</a>
            |
            <a href="#">Services</a>
            |
            <a href="#">Contact Us</a>
            |
            <a href="#">About Us</a>
            |
            <a href="#">Login</a>
            |
            <a href="#">Registration</a>
        </p>

        <p class="footer-company-name">© 2020 MediaBazaar Inc.</p>
    </div>

    <div class="footer-center">
        <div>
            <i class="fa fa-map-marker"></i>
            <p><span> Caplaan 66 </span>
                Eindhoven, Netherlands</p>
        </div>

        <div>
            <i class="fa fa-phone"></i>
            <p>+31 674 898 468</p>
        </div>
        <div>
            <i class="fa fa-envelope"></i>
            <p><a href="mailto:media_bazaar@gmail.com">media_bazaar@gmail.com</a></p>
        </div>
    </div>
    <div class="footer-right">
        <p class="footer-company-about">
            <span>About the company</span>
            Startup. Fresh Solutions. Good Results.</p>
        <div class="footer-icons">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-instagram"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
            <a href="#"><i class="fa fa-youtube"></i></a>
        </div>
    </div>
</footer>

</body>
</html>
