<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <link rel="icon" href="img/favicon.png" type="image/png" />
    <link
      rel="stylesheet"
      href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
      integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
      crossorigin="anonymous"
    />
    <title>Personal info</title>
   
    <link rel="stylesheet" href="personal-info.css" />
   
    
  </head>
  <body>
  <?php
require_once "navBar.php";
?>
 <div class="container">
            <div class="col-lg-6">
<h2 style="text-align:center">Personal information</h2>

<div class="card">
  <img src="./employee.jpg" alt="John" style="width:100%">
  <h1>Name</h1>
  <p class="title">Position</p>
  <p>email</p>
  <div style="margin: 24px 0;">
    <a href="#"><i class="fa fa-dribbble"></i></a> 
    <a href="#"><i class="fa fa-twitter"></i></a>  
    <a href="#"><i class="fa fa-linkedin"></i></a>  
    <a href="#"><i class="fa fa-facebook"></i></a> 
  </div>
  <p><button><a href="EditInfo.php">Edit infotmation</button></p>
</div></div></div>
<div class="container">
<div class="col-lg-6">
  <form action="/action_page.php">
  <div class="row">
    <div class="col-25">
      <label for="fname">Name</label>
    </div>
    <div class="col-75">
      <input type="text" id="fname" name="firstname" placeholder="Your name..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="lname">Email</label>
    </div>
    <div class="col-75">
      <input type="text" id="lname" name="lastname" placeholder="Your email...">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="lname">Phone</label>
    </div>
    <div class="col-75">
      <input type="text" id="lname" name="lastname" placeholder="Your phone number..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="country">Country</label>
    </div>
    <div class="col-75">
      <select id="country" name="country">
        <option value="australia">Netherlands</option>
        <option value="canada">UK</option>
        <option value="usa">USA</option>
      </select>
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="subject">Description</label>
    </div>
    <div class="col-75">
      <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>
    </div>
  </div>
  <div class="row">
    <input type="submit" value="Edit information">
  </div>
  </form>
</div>
</div>
<!--<div class="container">
        <div class="profile_inner p_120">  
            <div class="col-lg-6">
<form method="POST">
              <div class="input-group">
                <input
                  class="input--style-3"
                  type="text"
                  placeholder="Userame"
                  name="name"
                />
              </div>
              <div class="input-group">
                <input
                  class="input--style-3 js-datepicker"
                  type="text"
                  placeholder="Password"
                  name="password"
                />
              </div>              
              <div class="p-t-10">
                <button class="btn btn--pill btn--green" type="submit">
                  Login
                </button>
              </div>
            </form>
</div>
</div>
</div>-->
  </body>
</html>
